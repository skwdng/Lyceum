import { createRouter, createWebHashHistory } from 'vue-router';
import { useAuthStore } from './stores/auth.js';
import { useAdminStore } from './stores/admin.js';
import { getAdminToken } from './api.js';
import { trackView } from './utils/track.js';
import LoginView from './views/LoginView.vue';
import MeView from './views/MeView.vue';
import NotifyView from './views/NotifyView.vue';
import FriendsView from './views/FriendsView.vue';
import HotView from './views/HotView.vue';
import RecordsView from './views/RecordsView.vue';
import DiagView from './views/DiagView.vue';
import WalletView from './views/WalletView.vue';
import ChatView from './views/ChatView.vue';
import SoloView from './views/SoloView.vue';
import OfflineView from './views/OfflineView.vue';
import MatchView from './views/MatchView.vue';
import ReviewView from './views/ReviewView.vue';
import RoomView from './views/RoomView.vue';
import CommunityView from './views/CommunityView.vue';
import PostDetailView from './views/PostDetailView.vue';
import VideoView from './views/VideoView.vue';

/**
 * 路由表。
 *
 * ⚠️ **必须是 hash 模式**：后端是 Spring，没有 SPA fallback，
 * 用 history 模式一刷新就 404（`/siyige/v2/records` 找不到）。
 *
 * 迁移期的两条规则：
 * 1. 已迁移页面 → 挂真组件；
 * 2. 批 4 之后所有页面都在本应用内，旧前端已删除，没有任何回落路由。
 *    —— 这样侧栏永远点得通，用户不会撞到空白页，我们也能一批一批搬。
 *
 * `meta.legacy` 的值必须是旧前端 boot() 认得的键（solo/room/hotb/diag/records/community/video/chat/friends/notify/me）。
 */
const routes = [
  // 默认落点必须是**已迁移**的页面。
  // 早先这里 redirect 到 /community，而社区要批 3 才迁，结果是从旧页点「试用新版」进来后
  // 用 catch-all 兜住 —— 否则用户会看到"点了没反应"。
  // 现在统一进 /me：未登录时 MeView 自己会再跳 /login，最多一跳。
  { path: '/', redirect: '/me' },

  // ---- 批 0：已经迁移 ----
  { path: '/login', name: 'login', component: LoginView },
  { path: '/me', name: 'me', component: MeView },

  // ---- 批 1：已迁移（通知/好友/热辩榜/记录/诊断/钱包）----
  { path: '/notify', name: 'notify', component: NotifyView, meta: { requiresAuth: true } },
  { path: '/friends', name: 'friends', component: FriendsView, meta: { requiresAuth: true } },
  { path: '/hot', name: 'hot', component: HotView },
  { path: '/records', name: 'records', component: RecordsView, meta: { requiresAuth: true } },
  { path: '/diag', name: 'diag', component: DiagView, meta: { requiresAuth: true } },
  { path: '/wallet', name: 'wallet', component: WalletView, meta: { requiresAuth: true } },

  // ---- 批 2：单人/对局/复盘已迁移，房间待迁 ----
  { path: '/solo', name: 'solo', component: SoloView, meta: { requiresAuth: true } },
  { path: '/offline', name: 'offline', component: OfflineView, meta: { requiresAuth: true } },
  { path: '/room', name: 'room', component: RoomView, meta: { requiresAuth: true } },
  { path: '/chat', name: 'chat', component: ChatView, meta: { requiresAuth: true } },
  { path: '/match', name: 'match', component: MatchView, meta: { requiresAuth: true } },
  { path: '/review', name: 'review', component: ReviewView, meta: { requiresAuth: true } },

  // ---- 批 3 ----
  { path: '/community', name: 'community', component: CommunityView },
  // 帖子详情走真实路由：通知点「帖子类」通知可以直接深链过来（?around=<评论id> 定位楼层）
  { path: '/community/:postId', name: 'community-post', component: PostDetailView },
  { path: '/video', name: 'video', component: VideoView },
  // 管理后台是独立 app：裸布局（无主站侧栏）、自己的令牌 sy_admin_jwt、自己的前缀 /api/admin。
  // 结构与设计文档 §4.2 一致：父级只做布局（AdminLayout = 侧栏 + 顶栏 + RouterView），
  // 子页全部懒加载 —— 首屏只加载布局，进哪个子页才拉哪个子页的 chunk。
  //
  // meta 会沿匹配链合并：父级的 bare:true 对子路由同样生效（App.vue 靠它跳过 AppShell），
  // 子级各自的 title 给顶栏用，guest:true 表示"登录页，不需要令牌"。
  {
    path: '/admin',
    meta: { bare: true },
    component: () => import('./views/admin/AdminLayout.vue'),
    children: [
      { path: '', redirect: '/admin/dashboard' },
      { path: 'login', name: 'admin-login', component: () => import('./views/admin/AdminLogin.vue'), meta: { guest: true } },
      // 首登 / 重置密码后强制改密：这条路由**不受 mustChangePwd 拦截**（否则就是死锁）
      {
        path: 'change-password',
        name: 'admin-change-password',
        component: () => import('./views/admin/ChangePasswordView.vue'),
        meta: { title: '修改密码', pwdChangeAllowed: true }
      },
      { path: 'dashboard', name: 'admin-dashboard', component: () => import('./views/admin/DashboardView.vue'), meta: { title: '概览', perm: 'analytics:read' } },
      { path: 'analytics', name: 'admin-analytics', component: () => import('./views/admin/AnalyticsView.vue'), meta: { title: '报表分析', perm: 'analytics:read' } },
      {
        path: 'reports',
        name: 'admin-reports',
        component: () => import('./views/admin/ReportsView.vue'),
        meta: { title: '举报处理', badge: 'pendingReports', perm: 'report:read' }
      },
      { path: 'users', name: 'admin-users', component: () => import('./views/admin/UsersView.vue'), meta: { title: '用户管理', perm: 'user:read' } },
      { path: 'content/posts', name: 'admin-content-posts', component: () => import('./views/admin/ContentPostsView.vue'), meta: { title: '帖子管理', perm: 'content:read' } },
      { path: 'content/comments', name: 'admin-content-comments', component: () => import('./views/admin/ContentCommentsView.vue'), meta: { title: '评论管理', perm: 'content:read' } },
      { path: 'tags', name: 'admin-tags', component: () => import('./views/admin/TagsView.vue'), meta: { title: '标签管理', perm: 'content:moderate' } },
      { path: 'alerts', name: 'admin-alerts', component: () => import('./views/admin/AlertsView.vue'), meta: { title: '告警', perm: 'analytics:read' } },
      { path: 'video-audit', name: 'admin-video-audit', component: () => import('./views/admin/VideoAuditView.vue'), meta: { title: '视频复核', perm: 'video:read' } },
      { path: 'topics', name: 'admin-topics', component: () => import('./views/admin/TopicReviewView.vue'), meta: { title: '辩题审核', perm: 'topic:read' } },
      { path: 'audit', name: 'admin-audit', component: () => import('./views/admin/AuditView.vue'), meta: { title: '处理记录', perm: 'audit:read' } },
      { path: 'admins', name: 'admin-admins', component: () => import('./views/admin/AdminsView.vue'), meta: { title: '管理员管理', perm: 'admin:manage' } },
      // 参数管理（第一批 10 项）：与管理员管理同一档权限 —— 参数影响钱与功能开关，只给超管
      { path: 'config', name: 'admin-config', component: () => import('./views/admin/ConfigView.vue'), meta: { title: '参数管理', perm: 'admin:manage' } },
      { path: 'settings', name: 'admin-settings', component: () => import('./views/admin/SettingsView.vue'), meta: { title: '设置' } }
    ]
  },

  // 兜底：未知路径回 /me（同样不能回落到旧页，否则等于把人赶走）
  { path: '/:pathMatch(.*)*', redirect: '/me' }
];

const router = createRouter({
  // hash 模式不传 base：路由只用 # 后面的部分，与资源前缀（vite 的 base）解耦。
  // 传 import.meta.env.BASE_URL 的话，base 改成相对路径 './' 后这里会拿到 './'，容易出怪 URL。
  history: createWebHashHistory(),
  routes
});

/**
 * 登录守卫：等价于旧版的 `LOGIN_ONLY_VIEWS` + `needLogin()`。
 *
 * 未登录时给的是**登录引导卡**（由 AppShell 渲染），不是硬跳登录页——
 * 旧版行为就是这样：点「辩论记录」先看到「登录后可见」，再点按钮去登录。
 *
 * 管理台的门禁也在这里，但用的是**另一套令牌**（`sy_admin_jwt`）：
 * 管理台没有"引导卡"，没令牌就直接赶回登录页 —— 与旧 admin.js 一致。
 */
const ADMIN_LOGIN_PATH = '/admin/login';

router.beforeEach(async (to) => {
  const auth = useAuthStore();
  // 首次进入时 token 还在、user 还没恢复：先恢复一次，否则刷新后会误判成未登录
  if (!auth.user && auth.hasToken) await auth.restore();

  // 管理台：与上面的用户登录态完全无关（两个 app、两套令牌）
  if (to.path === '/admin' || to.path.startsWith('/admin/')) {
    const hasAdmin = !!getAdminToken();
    // 无令牌且目标不是登录页 -> 登录页（深链 /admin/reports 刷新后也不会白屏）
    if (!hasAdmin && to.meta.guest !== true) return { path: ADMIN_LOGIN_PATH, replace: true };
    // 已登录还去登录页 -> 概览（避免登录后按浏览器"后退"又回到表单）
    if (hasAdmin && to.meta.guest === true) return { path: '/admin/dashboard', replace: true };

    if (hasAdmin) {
      const admin = useAdminStore();
      // 刷新后 me 是空的：先补一次，否则菜单/无权限判断都会误判
      if (!admin.me) await admin.loadMe();
      // 首登 / 重置密码后**只能去改密页**（后端也拦：除改密与 /me 之外一律 403）
      if (admin.mustChangePwd && !to.meta.pwdChangeAllowed) {
        return { name: 'admin-change-password', replace: true };
      }
      // 登录落点是概览，但概览要 analytics:read（MOD 没有）：
      // 这种情况换个有权限的落点，别一登录就给「无权限」卡片
      if (to.name === 'admin-dashboard' && admin.me && !admin.has('analytics:read')) {
        return { path: admin.firstAllowedPath(), replace: true };
      }
      // 改完密之后不该再停在改密页
      if (!admin.mustChangePwd && to.meta.pwdChangeAllowed && !to.query.voluntary) {
        return { path: '/admin/dashboard', replace: true };
      }
    }
  }

  return true;
});

/**
 * 模块浏览上报（管理台报表 P1）：每次跳转都把「路径 -> 模块」报给后端。
 *
 * 放在 afterEach 而不是 beforeEach：只统计**真正落地**的页面（被守卫拦下来的跳转不算浏览）；
 * 去抖、白名单、失败静默都在 utils/track.js 里，这里只挂一行。
 */
router.afterEach((to) => {
  trackView(to.path);
});


export default router;
