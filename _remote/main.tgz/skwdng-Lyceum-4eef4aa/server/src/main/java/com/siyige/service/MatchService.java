package com.siyige.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.siyige.admin.analytics.Active;
import com.siyige.ai.AiService;
import com.siyige.api.SseHub;
import com.siyige.domain.Format;
import com.siyige.engine.TurnEngine;
import com.siyige.hot.HotRank;
import com.siyige.repo.Store;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * 对局编排：开局、玩家提交、AI 回合、超时推进、结算。
 * 计时权威在数据库 deadline_at（R-TECH-04），不依赖内存 Timer。
 */
@Service
public class MatchService {

    private static final Logger log = LoggerFactory.getLogger(MatchService.class);

    private final Store store;
    private final AiService ai;
    private final ScoreService scorer;
    private final UtteranceCheck utterance;
    private final java.util.Random rnd = new java.util.Random();
    private final com.siyige.billing.WalletService wallet;
    private final com.siyige.billing.UserLlmService userLlm;
    private final com.siyige.ai.AiTier aiTier;
    private final com.siyige.repo.RoomStore roomStore;
    private final HotRank hot;
    private final SseHub hub;
    private final FlawService flaw;
    private final ObjectMapper json;
    private final double timeScale;
    private final long aiThinkMs;
    private final int defaultTurnSeconds;
    private final double aiDelayScale;

    public MatchService(Store store, AiService ai, ScoreService scorer, HotRank hot, SseHub hub, FlawService flaw,
                        ObjectMapper json,
                        @Value("${siyige.pace.time-scale:1.0}") double timeScale,
                        @Value("${siyige.pace.ai-think-ms:1800}") long aiThinkMs,
                        @Value("${siyige.pace.turn-seconds:300}") int defaultTurnSeconds,
                        @Value("${siyige.pace.ai-delay-scale:1.0}") double aiDelayScale,
                        UtteranceCheck utterance,
                        com.siyige.billing.WalletService wallet,
                        com.siyige.billing.UserLlmService userLlm,
                        com.siyige.ai.AiTier aiTier,
                        com.siyige.repo.RoomStore roomStore) {
        this.store = store; this.ai = ai; this.scorer = scorer; this.hot = hot; this.hub = hub;
        this.flaw = flaw; this.json = json; this.timeScale = timeScale; this.aiThinkMs = aiThinkMs;
        this.defaultTurnSeconds = defaultTurnSeconds;
        this.aiDelayScale = aiDelayScale;
        this.utterance = utterance;
        this.wallet = wallet;
        this.userLlm = userLlm;
        this.aiTier = aiTier;
        this.roomStore = roomStore;
    }

    // ---------- 开局 ----------

    public String create(String userId, String topicId, String seatsRaw, String mode) throws Exception {
        return create(userId, topicId, seatsRaw, mode, 0);
    }

    public String create(String userId, String topicId, String seatsRaw, String mode, int turnSeconds) throws Exception {
        return create(userId, topicId, seatsRaw, mode, turnSeconds, "normal", "pro");
    }

    public String create(String userId, String topicId, String seatsRaw, String mode, int turnSeconds, String pace) throws Exception {
        return create(userId, topicId, seatsRaw, mode, turnSeconds, pace, "pro", "solo");
    }

    public String create(String userId, String topicId, String seatsRaw, String mode, int turnSeconds,
                         String pace, String difficulty) throws Exception {
        return create(userId, topicId, seatsRaw, mode, turnSeconds, pace, difficulty, "solo");
    }

    public String create(String userId, String topicId, String seatsRaw, String mode, int turnSeconds,
                         String pace, String difficulty, String kind) throws Exception {
        return create(userId, topicId, seatsRaw, mode, turnSeconds, pace, difficulty, kind, null, null);
    }

    /** 带 AI 档位与付款人的开局（多人房间传房主为付款人）。 */
    @Active
    public String create(String userId, String topicId, String seatsRaw, String mode, int turnSeconds,
                         String pace, String difficulty, String kind, String tierRaw, String payerUserId) throws Exception {
        Set<String> seats = TurnEngine.parseSeats(seatsRaw);
        for (String s : seats) {
            if (!TurnEngine.validSeat(s)) throw new IllegalArgumentException("非法席位: " + s);
        }
        Map<String, Object> topic = store.topic(topicId);
        if (topic == null) throw new IllegalArgumentException("辩题不存在");

        String id = "m" + UUID.randomUUID().toString().replace("-", "").substring(0, 10);
        // 质询 2–4 轮/方，自由辩 3–6 轮，每场随机——真实比赛不固定
        int queryRounds = Format.randomQueryRounds(rnd);
        int freeRounds = Format.randomFreeRounds(rnd);
        List<Format.Step> steps = Format.stepsOf(mode, queryRounds, freeRounds);
        boolean firstMine = TurnEngine.isMine(seats, steps.get(0).seat());
        int turnSec = stepSeconds(steps.get(0), turnSeconds, pace, kind);
        // 开场不需要"等对方说完"，AI 直接开口（1.2 秒）
        Long deadline = firstMine ? deadlineFor(turnSec) : Long.valueOf(openingDelay());
        String tier = aiTier == null ? "PRO" : aiTier.normalize(tierRaw);
        store.createMatch(id, userId, topicId, String.valueOf(topic.get("title")), mode,
                TurnEngine.joinSeats(seats), turnSec, pace, difficulty, kind, deadline,
                queryRounds, freeRounds, tier, payerUserId);
        // 档位落地：BYOK 需要真的有 key；没配 key 就退回 PRO
        if ("BYOK".equals(tier) && userLlm != null) {
            if (userLlm.profileOf(userId) == null) {
                tier = "PRO";
                store.setTier(id, tier);
            } else {
                store.setOwnKey(id, true);
            }
        } else if (userLlm != null && userLlm.profileOf(userId) != null) {
            // 配了自己的 key 但没选档位：默认按自带 Key 走（不多收模型成本）
            store.setOwnKey(id, true);
        }

        // 计费：基础版 / 自带 Key 都免费，不预扣；只有高级版按预估冻结
        boolean freeTier = "BYOK".equals(tier)
                || (aiTier != null && !aiTier.chargeModelCost(tier) && !aiTier.chargeServiceFee(tier));
        String payer = (payerUserId == null || payerUserId.isBlank()) ? userId : payerUserId;
        if (wallet != null && !freeTier) {
            long held = wallet.hold(payer, id);
            if (held < 0) {
                throw new IllegalStateException("余额不足，请先充值（本场预估 "
                        + (wallet.estimateCents() / 100.0) + " 元）");
            }
            store.setTokenBase(id, wallet.tokenSnapshot());
        }

        store.incPlays(topicId);
        hot.zincrby(topicId, 1);   // 开辩 +1
        hub.emit(id, "match.start", Map.of(
                "step", 1, "seg", steps.get(0).seg(), "seat", steps.get(0).seat(),
                "seconds", steps.get(0).sec(), "mySeats", TurnEngine.joinSeats(seats)));
        return id;
    }

    // ---------- 玩家提交 ----------

    @Active
    public Map<String, Object> submit(String matchId, String content, String inputType) throws Exception {
        return submit(matchId, content, inputType, null);
    }

    /**
     * 玩家提交发言。
     *
     * @param userId 提交者；**联机对局必须传**，否则会退化成
     *               「这场里任意一个真人席位都能替对方发言」（2026-11-14 线上实测踩到：
     *               B 方提交的内容被记成了 A1 的发言）
     */
    public Map<String, Object> submit(String matchId, String content, String inputType, String userId) throws Exception {
        Map<String, Object> m = require(matchId);
        List<Format.Step> steps = Format.stepsOf(str(m.get("mode")), num(m.get("query_rounds")), num(m.get("free_rounds")));
        int step = num(m.get("step"));
        Format.Step cur = Format.stepAt(steps, step);
        if (cur == null) throw new IllegalStateException("对局已结束");

        Set<String> mine = TurnEngine.parseSeats(str(m.get("my_seats")));
        String buzzSeat = str(m.get("buzz_seat"));
        String speaker = buzzSeat.isBlank() ? cur.seat() : buzzSeat;   // 抢拍时以抢到的人为准
        if (!TurnEngine.isMine(mine, speaker))
            throw new IllegalStateException("NOT_YOUR_TURN: 当前轮到 " + speaker);

        // 真实席位校验：是谁在提交，就必须坐在当前发言席上
        String mySeat = seatOfUser(m, userId);
        if (mySeat != null && !mySeat.equals(speaker)) {
            throw new IllegalStateException("NOT_YOUR_TURN: 现在是 " + speaker + " 的回合，你坐 " + mySeat);
        }

        String text = content == null || content.isBlank() ? "（未发言）" : content.trim();
        // 敷衍发言（「11」「对」「嗯」）记为 EMPTY：不算内容，不计入评分文本，
        // 但对局照常推进——下一轮 AI 会明确点出「你这一轮没有回答问题」。
        String status = (utterance != null && utterance.vacuous(text)) ? "EMPTY" : "OK";
        String recordSeat = (mySeat != null && !mySeat.isBlank()) ? mySeat : speaker;
        store.insertTurn(matchId, step + 1, recordSeat, cur.seg(), text, status,
                inputType == null ? "kb" : inputType);
        hot.zincrby(str(m.get("topic_id")), 2);   // 发言 +2
        hub.emit(matchId, "turn", Map.of(
                "seat", cur.seat(), "seg", cur.seg(), "who", "me", "content", text));

        advance(matchId, m, steps, step);
        return Map.of("ok", true, "step", step + 1, "total", steps.size());
    }

    // ---------- 定时推进（AI 回合 / 超时） ----------

    /** 多久没动静算「没人管了」（毫秒）。比最长单步（180 秒）留足余量。 */
    private static final long ABANDON_AFTER_MS = 15 * 60 * 1000L;

    @Scheduled(fixedDelay = 250)
    public void tick() {
        reapAbandoned();
        for (Map<String, Object> m : store.runningMatches()) {
            try { tickOne(m); } catch (Exception e) { log.warn("tick {} failed: {}", m.get("id"), e.toString()); }
        }
    }

    /**
     * 回收「僵尸对局」：长时间没有任何推进的对局判 ABANDONED。
     *
     * <p>为什么要它：tick 每 250ms 扫描所有 RUNNING 对局，AI 调用串行排队。
     * 用户关掉页面 / 断网后，那场对局会永远停在 RUNNING 一直占用调度线程，
     * 攒几场之后正常对局的 AI 发言会被拖到几十秒（2026-11-14 压测实测）。
     *
     * <p>判据用「最后活跃时间」：deadline_at 每次推进都会刷新，正在打的对局不会被误杀。
     */
    private void reapAbandoned() {
        long now = System.currentTimeMillis();
        List<Map<String, Object>> running;
        try {
            running = store.runningMatches();
        } catch (Exception e) {
            return;
        }
        for (Map<String, Object> row : running) {
            try {
                long dl = num(row.get("deadline_at"));
                long started = num(row.get("started_at"));
                long anchorTs = Math.max(dl, started);
                if (anchorTs <= 0 || now - anchorTs < ABANDON_AFTER_MS) continue;

                String id = str(row.get("id"));
                log.info("回收僵尸对局 {}（{} 分钟无推进）", id, (now - anchorTs) / 60000);
                store.finishMatch(id, "ABANDONED", 0);
                settleBilling(id, row);          // 预扣的按实际用量结掉，不留挂账
                hub.emit(id, "match.end", Map.of("abandoned", true));
            } catch (Exception e) {
                log.warn("回收失败 {}: {}", str(row.get("id")), e.toString());
            }
        }
    }

    private void tickOne(Map<String, Object> m) throws Exception {
        String id = str(m.get("id"));
        Object dl = m.get("deadline_at");
        if (dl == null) return;
        Instant deadline = ((java.sql.Timestamp) dl).toInstant();
        long leftSec = java.time.Duration.between(Instant.now(), deadline).getSeconds();

        // 快结束了先推一条预警（只推一次）
        if (leftSec <= com.siyige.domain.Pace.WARN_SEC && leftSec > 0
                && !"true".equals(String.valueOf(m.get("warned")))) {
            store.markWarned(id);
            hub.emit(id, "warn", Map.of("leftSec", Math.max(0, leftSec), "step", num(m.get("step")) + 1));
        }
        if (Instant.now().isBefore(deadline)) return;

        List<Format.Step> steps = Format.stepsOf(str(m.get("mode")), num(m.get("query_rounds")), num(m.get("free_rounds")));
        int step = num(m.get("step"));
        Format.Step cur = Format.stepAt(steps, step);
        if (cur == null) { finish(id, m); return; }

        Set<String> mine = TurnEngine.parseSeats(str(m.get("my_seats")));

        // ── 自由辩抢拍阶段：窗口内谁抢到谁上 ──
        if ("BUZZ".equals(str(m.get("phase")))) {
            long windowMs = buzzWindowMs();
            long remainingMs = java.time.Duration.between(Instant.now(), deadline).toMillis();
            boolean expired = remainingMs <= 0;
            // 给玩家半个窗口的机会，之后 AI 才开始抢（否则 AI 一上来就抢光）
            boolean aiGrabs = remainingMs < windowMs * 0.35 && Math.random() < 0.3;
            if (!expired && !aiGrabs) return;
            String aiSeat = pickAiSeat(m, cur);
            if (aiSeat == null) return;                     // 全是玩家席位，等玩家抢
            ai.bind(id);
            applyTier(m);
            AiService.Speech sp;
            try {
                sp = aiLineFor(m, aiSeat, cur.seg());
            } finally {
                ai.clearOwnProfile();
                ai.unbind();
            }
            String line = sp.text();
            FlawService.Planted planted = flaw.plant(line, str(m.get("difficulty")));
            line = planted.text();
            store.insertTurn(id, step + 1, aiSeat, cur.seg(), line, sp.degraded() ? "TEMPLATE" : "OK", "ai");
            store.setPhase(id, "STEP");
            hub.emit(id, "turn", Map.of("seat", aiSeat, "seg", cur.seg(), "who", "ai",
                    "content", line, "buzzed", true));
            if (planted.type() != null) {
                store.insertFlaw(id, step + 1, planted.type());
                hub.emit(id, "flaw", Map.of("step", step + 1, "seat", aiSeat, "options", FlawService.TYPES));
            }
            advance(id, m, steps, step);
            return;
        }

        String buzzSeat2 = str(m.get("buzz_seat"));
        String speaker = buzzSeat2.isBlank() ? cur.seat() : buzzSeat2;   // 抢拍后以抢到的人为准

        if (TurnEngine.isMine(mine, speaker)) {
            store.insertTurn(id, step + 1, speaker, cur.seg(), "（超时未发言）", "TIMEOUT", "timeout");
            hub.emit(id, "turn", Map.of("seat", speaker, "seg", cur.seg(), "who", "me",
                    "content", "（超时未发言）", "timeout", true));
        } else {
            ai.bind(id);
            applyTier(m);
            AiService.Speech sp;
            try {
                sp = aiLineFor(m, cur.seat(), cur.seg());
            } finally {
                ai.clearOwnProfile();
                ai.unbind();
            }
            String line = sp.text();
            // 按难度概率埋一处逻辑漏洞，供玩家抓
            FlawService.Planted planted = flaw.plant(line, str(m.get("difficulty")));
            line = planted.text();
            store.insertTurn(id, step + 1, cur.seat(), cur.seg(), line, sp.degraded() ? "TEMPLATE" : "OK", "ai");
            hub.emit(id, "turn", Map.of("seat", cur.seat(), "seg", cur.seg(), "who", "ai", "content", line));
            if (planted.type() != null) {
                store.insertFlaw(id, step + 1, planted.type());
                hub.emit(id, "flaw", Map.of("step", step + 1, "seat", cur.seat(),
                        "options", FlawService.TYPES));
            }
        }
        advance(id, m, steps, step);
    }

    /** 抓漏：玩家指出某一轮 AI 发言的逻辑漏洞。 */
    public Map<String, Object> point(String matchId, int step, String type) {
        require(matchId);
        String planted = store.flawType(matchId, step);
        if (planted == null) return Map.of("ok", false, "reason", "这一轮没有漏洞可抓");
        boolean hit = planted.equals(type);
        store.markFlaw(matchId, step, hit);
        return Map.of("ok", true, "hit", hit, "correct", planted, "chosen", type);
    }

    /** 打字续命：玩家正在输入时把本步 deadline 往后推，每步最多 3 次。 */
    public Map<String, Object> keepalive(String matchId) {
        Map<String, Object> m = require(matchId);
        if (!"RUNNING".equals(str(m.get("status")))) return Map.of("extended", false, "reason", "not-running");
        int used = num(m.get("extend_count"));
        if (used >= com.siyige.domain.Pace.MAX_EXTEND)
            return Map.of("extended", false, "reason", "max", "used", used);

        List<Format.Step> steps = Format.stepsOf(str(m.get("mode")), num(m.get("query_rounds")), num(m.get("free_rounds")));
        Format.Step cur = Format.stepAt(steps, num(m.get("step")));
        if (cur == null) return Map.of("extended", false, "reason", "finished");
        if (!TurnEngine.isMine(TurnEngine.parseSeats(str(m.get("my_seats"))), cur.seat()))
            return Map.of("extended", false, "reason", "not-your-turn");

        // 单人模式 deadline_at 为空 = 不限时。绝不能在这里「续」出一个截止时间来，
        // 否则一打字就被判超时（曾经的 bug：发言被吞 + 记录 TIMEOUT）。
        if (m.get("deadline_at") == null)
            return Map.of("extended", false, "reason", "unlimited");

        // 续时不跟 time-scale 走：它的意义是「给人打字的时间」，压缩后等于没给。
        long deadline = System.currentTimeMillis()
                + (long) com.siyige.domain.Pace.EXTEND_SEC * 1000;
        store.extendDeadline(matchId, deadline);
        hub.emit(matchId, "extend", Map.of("addSec", com.siyige.domain.Pace.EXTEND_SEC, "used", used + 1));
        return Map.of("extended", true, "addSec", com.siyige.domain.Pace.EXTEND_SEC, "used", used + 1,
                "max", com.siyige.domain.Pace.MAX_EXTEND);
    }

    // ---------- 推进与结算 ----------

    private void advance(String matchId, Map<String, Object> m, List<Format.Step> steps, int step) throws Exception {
        int next = step + 1;
        if (next >= steps.size()) { finish(matchId, m); return; }
        Format.Step ns = steps.get(next);
        boolean mine = TurnEngine.isMine(TurnEngine.parseSeats(str(m.get("my_seats"))), ns.seat());
        int turnSec = stepSeconds(ns, 0, str(m.get("pace")), str(m.get("kind")));

        // 自由辩：先开一个抢话窗口，谁抢到谁上；其余环节按席次轮转
        boolean isBuzz = "自由辩".equals(ns.seg());
        Long deadline = isBuzz
                ? Long.valueOf(System.currentTimeMillis() + buzzWindowMs())
                : (mine ? deadlineFor(turnSec) : Long.valueOf(aiDeadline(ns.seat())));
        store.updateStep(matchId, next, deadline);
        store.setPhase(matchId, isBuzz ? "BUZZ" : "STEP");

        hub.emit(matchId, "step", Map.of(
                "step", next + 1, "seg", ns.seg(), "seat", ns.seat(),
                "seconds", isBuzz ? (int) (buzzWindowMs() / 1000) : (mine ? turnSec : 2),
                "mine", mine,
                "phase", isBuzz ? "BUZZ" : "STEP"));
    }

    /** 自由辩抢拍窗口：真实自由辩就是抢话，给 6 秒窗口。 */
    private long buzzWindowMs() {
        return Math.max(3000, (long) (8 * 1000 * Math.max(0.05, timeScale)));
    }

    /** 玩家点「抢」：抢到就拿到这一步的发言权。 */
    public Map<String, Object> buzz(String matchId) {
        Map<String, Object> m = require(matchId);
        if (!"BUZZ".equals(str(m.get("phase")))) return Map.of("ok", false, "reason", "现在不是抢拍时间");
        java.util.Set<String> mine = TurnEngine.parseSeats(str(m.get("my_seats")));
        if (mine.isEmpty()) return Map.of("ok", false, "reason", "你没有席位");
        String seat = mine.iterator().next();
        List<Format.Step> steps = Format.stepsOf(str(m.get("mode")), num(m.get("query_rounds")), num(m.get("free_rounds")));
        Format.Step cur = Format.stepAt(steps, num(m.get("step")));
        int turnSec = stepSeconds(cur, 0, str(m.get("pace")), str(m.get("kind")));
        store.setPhaseWithBuzz(matchId, "STEP", seat);      // 记下是谁抢到的
        store.updateStep(matchId, num(m.get("step")), deadlineFor(turnSec));
        hub.emit(matchId, "buzz.taken", Map.of("by", "me", "seat", seat));
        return Map.of("ok", true, "seat", seat, "seconds", turnSec);
    }

    /** AI 的"思考"停顿：按席位人设不同（快攻 0.9s、价值派 1.7s），再加抖动。 */
    private long aiDeadline(String seat) {
        // 一方说完，另一方至少隔 10 秒再回；区间 10–15 秒（按压缩系数缩放）
        long pick = 10_000L + (long) (5_000L * Math.random());
        long ms = Math.max(400, (long) (pick * Math.max(0.05, aiDelayScale)));
        return System.currentTimeMillis() + ms;
    }

    private long aiDeadline() { return aiDeadline("A1"); }

    /** 开场第一句：不等 10–15 秒，1.2 秒就开口。 */
    private long openingDelay() {
        return Math.max(300, (long) (1200 * Math.max(0.05, aiDelayScale)));
    }

    /** 在同侧里挑一个不是玩家的席位，用来"抢到话筒"。 */
    private String pickAiSeat(Map<String, Object> m, Format.Step cur) {
        Set<String> mine = TurnEngine.parseSeats(str(m.get("my_seats")));
        String side = Format.side(cur.seat());
        for (String s : Format.SEATS) {
            if (Format.side(s).equals(side) && !mine.contains(s)) return s;
        }
        return null;
    }

    /** 「催一下」的最小间隔：连点不生效（毫秒） */
    private static final long SKIP_COOLDOWN_MS = 3000;

    /**
     * 单人模式「催一下」：跳过 AI 的等待，让它立刻接话。
     *
     * <p>**幂等**：同一轮只生效一次。连点、脚本刷、以及"AI 已经在打字了又去催"都不会再起作用——
     * 之前没有这层保护，连点会把 deadline 反复推到过去，出现「一催就直接说完」的观感。
     */
    public Map<String, Object> skip(String matchId) {
        Map<String, Object> m = require(matchId);
        if (!"RUNNING".equals(str(m.get("status")))) return Map.of("ok", false, "reason", "对局已结束");
        if (!"solo".equalsIgnoreCase(str(m.get("kind"))))
            return Map.of("ok", false, "reason", "多人对局不能跳过");
        if ("BUZZ".equals(str(m.get("phase"))))
            return Map.of("ok", false, "reason", "抢拍阶段不能跳过");

        int step = num(m.get("step"));
        List<Format.Step> steps = Format.stepsOf(str(m.get("mode")), num(m.get("query_rounds")), num(m.get("free_rounds")));
        Format.Step cur = Format.stepAt(steps, step);
        if (cur == null) return Map.of("ok", false, "reason", "已结束");
        if (TurnEngine.isMine(TurnEngine.parseSeats(str(m.get("my_seats"))), cur.seat()))
            return Map.of("ok", false, "reason", "现在轮到你说");

        // ① 同一轮只允许催一次
        int skippedStep = num(m.get("skipped_step"));
        if (skippedStep == step) return Map.of("ok", false, "reason", "这一轮已经催过了");

        // ② 冷却：两次催之间至少 3 秒（防脚本连点）
        long lastAt = num(m.get("last_skip_at"));
        long now = System.currentTimeMillis();
        if (now - lastAt < SKIP_COOLDOWN_MS) {
            long wait = (SKIP_COOLDOWN_MS - (now - lastAt) + 999) / 1000;
            return Map.of("ok", false, "reason", "别急，" + wait + " 秒后再催");
        }

        // ③ 落库：先记账再改 deadline，两步都做才算成功
        store.setSkip(matchId, step, now);
        store.updateStep(matchId, step, now - 1);
        hub.emit(matchId, "skip", Map.of("step", step + 1));
        return Map.of("ok", true);
    }
    /** 结算本场费用：按实际 token 用量多退少补。 */
    /**
     * 单人模式走两段式（先分析对方 → 再生成），多人房间保持单段生成。
     * 返回 Speech 而不是 String，是为了把「本轮是否降级成模板」带给落库层。
     */
    /**
     * 单人模式的流式版本：边生成边把增量推给前端。
     *
     * <p>前端收到 {@code token} 事件就开始渲染，不用等整段生成完再"假装打字"。
     * 首发延迟从「等模型说完（约 8 秒）」降到「模型说出第一个字（约 1 秒）」。
     */
    private AiService.Speech aiLineStream(Map<String, Object> m, String seat, String seg) throws Exception {
        String id = str(m.get("id"));
        return ai.speakForSoloStream(seat, seg, str(m.get("topic_title")),
                str(m.get("topic_id")), str(m.get("difficulty")), store.turns(id),
                delta -> hub.emit(id, "token", Map.of("seat", seat, "seg", seg, "delta", delta)));
    }

    /** 单人 → 流式；多人房间 → 整段（广播给多个人，增量推太碎没意义） */
    private AiService.Speech aiLineFor(Map<String, Object> m, String seat, String seg) throws Exception {
        if ("solo".equalsIgnoreCase(str(m.get("kind")))) return aiLineStream(m, seat, seg);
        return aiLine(m, seat, seg);
    }

    private AiService.Speech aiLine(Map<String, Object> m, String seat, String seg) throws Exception {
        String id = str(m.get("id"));
        if ("solo".equals(str(m.get("kind")))) {
            return ai.speakForSolo(seat, seg, str(m.get("topic_title")),
                    str(m.get("topic_id")), str(m.get("difficulty")), store.turns(id));
        }
        String line = ai.speak(seat, seg, str(m.get("topic_title")),
                str(m.get("topic_id")), str(m.get("difficulty")), store.turns(id));
        return new AiService.Speech(line, false, "");
    }

    /**
     * 按本场档位切换模型：
     * BASIC → 本地 ollama；BYOK → 用户自己的 key；PRO → 平台默认（不动 profile）。
     */
    /**
     * 把提交者映射到席位：
     * · 房间对局：查 sy_seat 里这个人坐哪（房码 → 席位）；
     * · 单人：对局里 my_seats 只有一个，直接取。
     *
     * @return 解析不出来时返回 null（老客户端不传 userId 的情况，保持兼容）
     */
    private String seatOfUser(Map<String, Object> m, String userId) {
        if (userId == null || userId.isBlank()) return null;
        if ("room".equalsIgnoreCase(str(m.get("kind"))) && roomStore != null) {
            String code = roomStore.codeOfMatch(str(m.get("id")));
            if (code != null) {
                String s = roomStore.seatOfUser(code, userId);
                if (s != null) return s;
            }
        }
        Set<String> mine = TurnEngine.parseSeats(str(m.get("my_seats")));
        return mine.isEmpty() ? null : mine.iterator().next();
    }

    private void applyTier(Map<String, Object> m) {
        String tier = str(m.get("tier"));
        String owner = str(m.get("user_id"));
        if ("BYOK".equals(tier) || "true".equalsIgnoreCase(str(m.get("own_key")))) {
            ai.useOwnProfile(owner, userLlm);
            return;
        }
        if (aiTier != null) {
            var p = aiTier.profileOf(tier);
            if (p != null) ai.useProfile(p);      // BASIC
        }
    }

    private void settleBilling(String matchId, Map<String, Object> m) {
        if (wallet == null) return;
        try {
            // 付款人：多人房间由房主承担；单人就是自己
            String userId = str(m.get("payer_user_id"));
            if (userId.isBlank()) userId = str(m.get("user_id"));

            String tier = str(m.get("tier"));
            // 基础版（本地模型）：免费，不结算也不扣服务费
            if (aiTier != null && !aiTier.chargeModelCost(tier) && !aiTier.chargeServiceFee(tier)) {
                Map<String, Object> bill = Map.of("freeTier", true, "tier", tier,
                        "tokens", 0, "modelCostCents", 0, "serviceFeeCents", 0, "totalCents", 0);
                store.saveBill(matchId, 0);
                hub.emit(matchId, "bill", bill);
                ai.clearMatchUsage(matchId);
                return;
            }
            // 按对局精确归集：不受其它对局 / 其它接口调用影响
            boolean own = "true".equalsIgnoreCase(str(m.get("own_key"))) || "BYOK".equals(tier);
            if (own) {
                // 自带 Key：模型成本不计，服务费也不收（可能指向用户本地模型，平台零成本）
                Map<String, Object> bill = wallet.settleOwnKey(userId, matchId);
                store.saveBill(matchId, 0);
                hub.emit(matchId, "bill", bill);
                ai.clearMatchUsage(matchId);
                return;
            }
            long used = ai.tokensForMatch(matchId);
            if (used <= 0) {
                // 兜底：极端情况下（模型未启用、全部走模板）用全局差值
                long base = num(m.get("token_base"));
                used = Math.max(0, wallet.tokenSnapshot() - base);
            }
            Map<String, Object> bill = wallet.settle(userId, matchId, used);
            store.saveBill(matchId, used);
            ai.clearMatchUsage(matchId);
            hub.emit(matchId, "bill", bill);
        } catch (Exception e) {
            log.warn("结算失败 {}: {}", matchId, e.toString());
        }
    }

    /**
     * 本场是否有「真人队友」。
     *
     * <p>注意：单人模式里同侧还有 AI 补位（B1/B3/B4 都是 AI），它们不算队友；
     * 只有同侧其它席位由真人发言（input_type != "ai"）才算。否则单人模式的协同维度
     * 会被 AI 的发言带成 100 或 0，画像就不准了。
     */
    private boolean hasTeammate(List<Map<String, Object>> turns, java.util.Set<String> mine) {
        if (mine.isEmpty()) return false;
        String side = str(mine.iterator().next()).substring(0, 1);
        for (Map<String, Object> t2 : turns) {
            String seat = str(t2.get("seat"));
            if (seat.length() < 2) continue;
            if (!seat.startsWith(side) || mine.contains(seat)) continue;
            String input = str(t2.get("input_type"));
            if (!"ai".equalsIgnoreCase(input)) return true;   // 真人队友
        }
        return false;
    }

    private void finish(String matchId, Map<String, Object> m) throws Exception {
        settleBilling(matchId, m);
        List<Map<String, Object>> turns = store.turns(matchId);
        Set<String> mine = TurnEngine.parseSeats(str(m.get("my_seats")));
        ScoreService.Score sc = scorer.score(turns, mine, str(m.get("topic_id")), store.flaws(matchId));

        store.finishMatch(matchId, "FINISHED", sc.total());
        hot.zincrby(str(m.get("topic_id")), 5 + sc.turns() * 0.0);   // 打完 +5

        // 六维画像：滑动平均（含场次样本数）+ 本场数据单独存一份，用于算增量
        Map<String, Object> diag = store.diag(str(m.get("user_id")));
        int prevSamples = diag == null ? 0 : num(diag.get("samples"));
        Map<String, Integer> avg = new LinkedHashMap<>();
        Map<String, Integer> flaws = new LinkedHashMap<>();
        if (diag != null && diag.get("dims_json") != null) {
            avg = json.readValue(str(diag.get("dims_json")), Map.class);
            if (diag.get("flaws_json") != null) {
                flaws = json.readValue(str(diag.get("flaws_json")), Map.class);
            }
        }
        Map<String, Integer> now = new LinkedHashMap<>();
        now.put("立论", sc.matter());
        now.put("论证", sc.method());
        now.put("表达", sc.manner());
        now.put("应变", sc.adapt());
        now.put("论据", sc.evidence());
        // 第六维：协同（本场协同分 0–3 换算成 0–100）
        // 单人模式没有队友，协同分恒为 0，这时记中性基线 60，否则会把画像冤枉成短板
        boolean hasMate = hasTeammate(turns, mine);
        now.put("协同", hasMate
                ? (int) Math.min(100, Math.round(sc.collab() * 100.0 / 3))
                : 60);

        if (avg.isEmpty()) {
            avg = new LinkedHashMap<>(now);
        } else {
            for (Map.Entry<String, Integer> e : now.entrySet()) {
                int old = avg.getOrDefault(e.getKey(), e.getValue());
                // 滑动平均：第 n+1 场 = (旧均值×n + 本场) / (n+1)
                avg.put(e.getKey(), (int) Math.round((old * (double) prevSamples + e.getValue()) / (prevSamples + 1)));
            }
        }
        // 瑕疵：真正检出什么就累加什么，不再写死
        for (Map.Entry<String, Integer> e : sc.flaws().entrySet()) {
            flaws.merge(e.getKey(), e.getValue(), Integer::sum);
        }
        int streak = diag == null ? 1 : num(diag.get("streak")) + 1;
        store.saveDiag(str(m.get("user_id")), json.writeValueAsString(avg), json.writeValueAsString(flaws),
                streak, prevSamples + 1, json.writeValueAsString(now));

        // 记录本场（含六维），供能力分析按「最近 N 场」重新聚合
        store.insertRecord(str(m.get("user_id")), matchId, str(m.get("topic_title")),
                str(m.get("my_seats")), sc.total(), sc.turns(), json.writeValueAsString(now));

        hub.emit(matchId, "match.end", Map.of(
                "total", sc.total(), "matter", sc.matter(), "method", sc.method(), "manner", sc.manner(),
                "turns", sc.turns(), "timeout", sc.timeout()));

        hub.emit(matchId, "match.end", Map.of(
                "total", sc.total(), "matter", sc.matter(), "method", sc.method(), "manner", sc.manner(),
                "turns", sc.turns(), "timeout", sc.timeout()));
    }

    // ---------- 查询 ----------

    public Map<String, Object> detail(String matchId) throws Exception {
        Map<String, Object> m = require(matchId);
        List<Format.Step> steps = Format.stepsOf(str(m.get("mode")), num(m.get("query_rounds")), num(m.get("free_rounds")));
        int step = num(m.get("step"));
        Format.Step cur = Format.stepAt(steps, step);
        Set<String> mine = TurnEngine.parseSeats(str(m.get("my_seats")));

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("match", m);
        out.put("steps", steps);
        out.put("currentStep", cur);
        boolean running = "RUNNING".equals(str(m.get("status")));
        String buzzSeat = str(m.get("buzz_seat"));
        String speaker = (buzzSeat.isBlank() && cur != null) ? cur.seat() : buzzSeat;
        out.put("buzzSeat", buzzSeat);
        out.put("waitingForMe", running && speaker != null && TurnEngine.isMine(mine, speaker));
        out.put("waitingSeat", running && cur != null ? cur.seat() : null);
        out.put("turnSec", num(m.get("turn_sec")) > 0 ? num(m.get("turn_sec")) : defaultTurnSeconds);
        out.put("pace", str(m.get("pace")));
        out.put("phase", str(m.get("phase")));
        out.put("kind", str(m.get("kind")));
        out.put("unlimited", "solo".equalsIgnoreCase(str(m.get("kind"))));
        out.put("extendUsed", num(m.get("extend_count")));
        Object dl = m.get("deadline_at");
        long left = dl == null ? 0 : java.time.Duration.between(Instant.now(), ((java.sql.Timestamp) dl).toInstant()).getSeconds();
        out.put("remainingSec", Math.max(0, left));   // 房间模式下前端据此判断是不是自己
        out.put("turns", store.turns(matchId));
        return out;
    }

    public Map<String, Object> review(String matchId) throws Exception {
        Map<String, Object> m = require(matchId);
        List<Map<String, Object>> turns = store.turns(matchId);
        Set<String> mine = TurnEngine.parseSeats(str(m.get("my_seats")));
        ScoreService.Score sc = scorer.score(turns, mine, str(m.get("topic_id")), store.flaws(matchId));
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("score", sc);
        // 按席位分别给分：占两个位置时能看出每个位置打得怎么样
        out.put("seatScores", scorer.scorePerSeat(turns, mine, str(m.get("topic_id")), store.flaws(matchId)));
        out.put("turns", turns);
        out.put("billTokens", num(m.get("bill_tokens")));
        out.put("queryRounds", num(m.get("query_rounds")));
        out.put("freeRounds", num(m.get("free_rounds")));
        return out;
    }

    // ---------- 工具 ----------

    private Map<String, Object> require(String matchId) {
        Map<String, Object> m = store.match(matchId);
        if (m == null) throw new IllegalArgumentException("对局不存在: " + matchId);
        return m;
    }

    /**
     * 计时：优先用用户指定的每步时长（turnSec），否则用赛制默认。
     * 再乘压缩系数——演示环境 0.05，生产 1.0。
     */
    /** seconds <= 0 表示不限时，返回 null（库里的 deadline_at 为空）。 */
    private Long deadlineFor(int seconds) {
        if (seconds <= 0) return null;
        long ms = Math.max(3000, (long) (seconds * 1000 * timeScale));
        return System.currentTimeMillis() + ms;
    }
    /** 单人 0（不限时），多人上限 600 秒。 */
    private int stepSeconds(Format.Step s, int overrideSec, String pace, String kind) {
        if ("solo".equalsIgnoreCase(kind)) return 0;
        if (overrideSec > 0 && overrideSec != defaultTurnSeconds) return overrideSec;
        return Math.min(600, com.siyige.domain.Pace.secondsFor(s.seg(), pace));
    }
    private static String str(Object o) { return o == null ? "" : String.valueOf(o); }
    private static int num(Object o) { return o instanceof Number n ? n.intValue() : 0; }

    /** AI 思考停顿（R-PACE-01），按压缩系数缩放。 */
    public long thinkMs() { return Math.max(400, (long) (aiThinkMs * Math.max(0.05, timeScale))); }

    public Duration prepareDuration() { return Duration.ofMillis(Math.max(2000, (long) (10_000 * timeScale))); }
}
